import './assets/index.ts-BcYw2g9s.js';
