var e=null,t=new Map,n=new Set,r=new Map,i=200;function a(e){return e.toLowerCase()}function o(e,t,n=!1){let r=new Map;for(let t of Object.keys(e))r.set(a(t),t);for(let[i,o]of Object.entries(t)){let t=a(i),s=r.get(t);s&&!n||(s&&delete e[s],e[i]=o,r.set(t,i))}return e}function s(){return new Promise(e=>{chrome.windows.getLastFocused({windowTypes:[`normal`]},t=>{if(!t.id){e(null);return}chrome.tabs.query({active:!0,windowId:t.id},t=>{e(t[0]?.id||null)})})})}function c(e){e===`sidepanel`?(chrome.action.setPopup({popup:``}),chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0})):(chrome.action.setPopup({popup:``}),chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!1}))}chrome.storage.local.get(`devtoolkit-display-mode`,e=>{c(e[`devtoolkit-display-mode`]||`sidepanel`)}),chrome.action.onClicked.addListener(t=>{chrome.storage.local.get(`devtoolkit-display-mode`,n=>{(n[`devtoolkit-display-mode`]||`sidepanel`)===`popup`?chrome.windows.create({url:chrome.runtime.getURL(`src/popup/index.html`),type:`popup`,width:500,height:640},t=>{t?.id&&(e=t.id)}):t.id!=null&&chrome.sidePanel.open({tabId:t.id})})});function l(){try{chrome.alarms.create(`devtoolkit-keepalive`,{periodInMinutes:.4})}catch{}}function u(){try{chrome.alarms.clear(`devtoolkit-keepalive`)}catch{}}try{chrome.alarms.onAlarm.addListener(e=>{e.name===`devtoolkit-keepalive`&&n.size===0&&u()})}catch{}chrome.runtime.onMessage.addListener((r,i,a)=>{if(r.type===`setDisplayMode`){let t=r.mode;return c(t),chrome.storage.local.set({"devtoolkit-display-mode":t}),t===`popup`?(e!=null&&(chrome.windows.remove(e),e=null),chrome.windows.create({url:chrome.runtime.getURL(`src/popup/index.html`),type:`popup`,width:500,height:640},t=>{t?.id&&(e=t.id)})):(e!=null&&(chrome.windows.remove(e),e=null),chrome.windows.getLastFocused({windowTypes:[`normal`]},e=>{e.id&&chrome.tabs.query({active:!0,windowId:e.id},e=>{e[0]?.id&&chrome.sidePanel.open({tabId:e[0].id})})})),a({ok:!0}),!0}if(r.type===`startCapture`){let e=r.tabId;return!e||e<0?(a({ok:!1,error:`无效的标签页ID: ${e}`}),!0):(chrome.debugger.attach({tabId:e},`1.3`,()=>{if(chrome.runtime.lastError){let t=chrome.runtime.lastError.message||``;if(t.includes(`already attached`)){n.add(e),l(),chrome.debugger.sendCommand({tabId:e},`Network.enable`,{},()=>{a({ok:!0})});return}a({ok:!1,error:`debugger.attach失败: ${t}`});return}n.add(e),l(),chrome.debugger.sendCommand({tabId:e},`Network.enable`,{},()=>{if(chrome.runtime.lastError){a({ok:!1,error:`Network.enable失败: ${chrome.runtime.lastError.message}`});return}a({ok:!0})})}),!0)}if(r.type===`stopCapture`){let e=r.tabId;return chrome.debugger.detach({tabId:e},()=>{n.delete(e),n.size===0&&u(),a({ok:!0})}),!0}if(r.type===`isDebuggerAttached`){let e=r.tabId;return chrome.debugger.getTargets(t=>{let r=t.some(t=>t.id===String(e)&&t.attached);r?n.add(e):n.delete(e),a({attached:r})}),!0}if(r.type===`getActiveTabId`)return s().then(e=>{a({tabId:e})}),!0;if(r.type===`getCapturedRequests`){let e=r.tabId,n=t.get(e)||[];return a({requests:JSON.parse(JSON.stringify(n))}),!0}if(r.type===`clearCapturedRequests`){let e=r.tabId;return t.delete(e),a({ok:!0}),!0}if(r.type===`syncTableToPage`){let e=r.domId,t=r.headers,n=r.rows;return s().then(r=>{if(!r){a({success:!1,error:`无法获取标签页`});return}chrome.scripting.executeScript({target:{tabId:r},func:(e,t,n)=>{let r=JSON.stringify({id:e,newHeaders:t,newRows:n}),i=document.createElement(`script`);i.textContent=`(function(){
            var data = ${r};
            var table = document.querySelector('table[data-devtoolkit-id="' + data.id + '"]');
            if (!table) return;

            function setInputValue(el, val) {
              el.focus();
              el.dispatchEvent(new Event('focus', {bubbles:true}));
              if (el.tagName === 'SELECT') {
                var found = false;
                var opts = el.querySelectorAll('option');
                opts.forEach(function(opt) {
                  if (opt.textContent.trim() === val || opt.value === val) {
                    opt.selected = true; opt.setAttribute('selected','selected'); found = true;
                  } else {
                    opt.selected = false; opt.removeAttribute('selected');
                  }
                });
                if (!found) {
                  var o = document.createElement('option');
                  o.value = val; o.textContent = val; o.selected = true;
                  el.appendChild(o);
                }
                var nativeSetter = Object.getOwnPropertyDescriptor(
                  HTMLSelectElement.prototype, 'value'
                );
                if (nativeSetter && nativeSetter.set) {
                  nativeSetter.set.call(el, val);
                } else {
                  el.value = val;
                }
              } else {
                var nativeSetter = Object.getOwnPropertyDescriptor(
                  el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value'
                );
                if (nativeSetter && nativeSetter.set) {
                  nativeSetter.set.call(el, val);
                } else {
                  el.value = val;
                }
              }
              el.dispatchEvent(new Event('input', {bubbles:true}));
              el.dispatchEvent(new Event('change', {bubbles:true}));
              el.dispatchEvent(new Event('blur', {bubbles:true}));
            }

            function setCellContent(cell, text) {
              var inputs = cell.querySelectorAll('input');
              var selects = cell.querySelectorAll('select');
              var textareas = cell.querySelectorAll('textarea');
              if (inputs.length > 0) inputs.forEach(function(el){ setInputValue(el, text); });
              if (selects.length > 0) selects.forEach(function(el){ setInputValue(el, text); });
              if (textareas.length > 0) textareas.forEach(function(el){ setInputValue(el, text); });
              if (inputs.length === 0 && selects.length === 0 && textareas.length === 0) {
                cell.textContent = text;
              }
            }

            if (data.newHeaders.length > 0) {
              var hCells = table.querySelectorAll('thead th, thead td');
              data.newHeaders.forEach(function(t, i) {
                if (i < hCells.length) setCellContent(hCells[i], t);
              });
            }

            var tbody = table.querySelector('tbody');
            if (!tbody) { tbody = document.createElement('tbody'); table.appendChild(tbody); }
            var existingRows = tbody.querySelectorAll(':scope > tr');
            var colCount = data.newHeaders.length || (data.newRows[0] ? data.newRows[0].length : 1);

            data.newRows.forEach(function(rowData, ri) {
              var tr;
              if (ri < existingRows.length) {
                tr = existingRows[ri];
              } else {
                tr = document.createElement('tr');
                for (var c = 0; c < colCount; c++) {
                  var td = document.createElement('td');
                  tr.appendChild(td);
                }
                tbody.appendChild(tr);
              }
              var cells = tr.querySelectorAll('td, th');
              rowData.forEach(function(text, ci) {
                if (ci < cells.length) setCellContent(cells[ci], text);
              });
            });

            for (var ri = existingRows.length - 1; ri >= data.newRows.length; ri--) {
              existingRows[ri].remove();
            }
          })();`,document.documentElement.appendChild(i),i.remove()},args:[e,t,n]}).then(()=>{a({success:!0})}).catch(e=>{a({success:!1,error:e.message||`脚本注入失败`})})}),!0}if(r.type===`syncListToPage`){let e=r.domId,t=r.items;return s().then(n=>{if(!n){a({success:!1,error:`无法获取标签页`});return}chrome.scripting.executeScript({target:{tabId:n},func:(e,t)=>{let n=JSON.stringify({id:e,newItems:t}),r=document.createElement(`script`);r.textContent=`(function(){
            var data = ${n};
            var list = document.querySelector('ul[data-devtoolkit-id="' + data.id + '"], ol[data-devtoolkit-id="' + data.id + '"]');
            if (!list) return;

            function setInputValue(el, val) {
              el.focus();
              el.dispatchEvent(new Event('focus', {bubbles:true}));
              if (el.tagName === 'SELECT') {
                var found = false;
                var opts = el.querySelectorAll('option');
                opts.forEach(function(opt) {
                  if (opt.textContent.trim() === val || opt.value === val) {
                    opt.selected = true; opt.setAttribute('selected','selected'); found = true;
                  } else {
                    opt.selected = false; opt.removeAttribute('selected');
                  }
                });
                if (!found) {
                  var o = document.createElement('option');
                  o.value = val; o.textContent = val; o.selected = true;
                  el.appendChild(o);
                }
                var nativeSetter = Object.getOwnPropertyDescriptor(
                  HTMLSelectElement.prototype, 'value'
                );
                if (nativeSetter && nativeSetter.set) {
                  nativeSetter.set.call(el, val);
                } else {
                  el.value = val;
                }
              } else {
                var nativeSetter = Object.getOwnPropertyDescriptor(
                  el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value'
                );
                if (nativeSetter && nativeSetter.set) {
                  nativeSetter.set.call(el, val);
                } else {
                  el.value = val;
                }
              }
              el.dispatchEvent(new Event('input', {bubbles:true}));
              el.dispatchEvent(new Event('change', {bubbles:true}));
              el.dispatchEvent(new Event('blur', {bubbles:true}));
            }

            function setItemContent(li, text) {
              var inputs = li.querySelectorAll('input');
              var selects = li.querySelectorAll('select');
              var textareas = li.querySelectorAll('textarea');
              if (inputs.length > 0) inputs.forEach(function(el){ setInputValue(el, text); });
              if (selects.length > 0) selects.forEach(function(el){ setInputValue(el, text); });
              if (textareas.length > 0) textareas.forEach(function(el){ setInputValue(el, text); });
              if (inputs.length === 0 && selects.length === 0 && textareas.length === 0) {
                li.textContent = text;
              }
            }

            var existingItems = list.querySelectorAll(':scope > li');

            data.newItems.forEach(function(text, i) {
              if (i < existingItems.length) {
                setItemContent(existingItems[i], text);
              } else {
                var li = document.createElement('li');
                li.textContent = text;
                list.appendChild(li);
              }
            });

            for (var i = existingItems.length - 1; i >= data.newItems.length; i--) {
              existingItems[i].remove();
            }
          })();`,document.documentElement.appendChild(r),r.remove()},args:[e,t]}).then(()=>{a({success:!0})}).catch(e=>{a({success:!1,error:e.message||`脚本注入失败`})})}),!0}return!1});try{chrome.debugger.onEvent.addListener((e,n,a)=>{if(!e.tabId)return;let s=e.tabId,c=a;if(n===`Network.requestWillBeSentExtraInfo`){let e={};if(c.headers)for(let[t,n]of Object.entries(c.headers))e[t]=String(n);let n=t.get(s)?.find(e=>e.id===c.requestId);if(n)o(n.headers,e,!0);else{let t=r.get(c.requestId);t?o(t,e,!0):r.set(c.requestId,e)}}if(n===`Network.requestWillBeSent`){let e=c.type;if(e!==`XHR`&&e!==`Fetch`)return;let n={};if(c.request?.headers)for(let[e,t]of Object.entries(c.request.headers))n[e]=String(t);let a=r.get(c.requestId);a&&(o(n,a,!0),r.delete(c.requestId));let l=null;c.request?.postData&&(l=c.request.postData);let u=n[`Content-Type`]||n[`content-type`]||null,d=t.get(s)?.find(e=>e.id===c.requestId);if(d){d.url=c.request.url,d.method=c.request.method,o(d.headers,n,!1),d.requestBody=l,d.contentType=u;return}let f={id:c.requestId,url:c.request.url,method:c.request.method,type:e===`Fetch`?`fetch`:`xhr`,timestamp:c.wallTime?c.wallTime*1e3:Date.now(),requestBody:l,contentType:u,headers:n,status:null,tabId:s,responseHeaders:{},responseBody:null};t.has(s)||t.set(s,[]);let p=t.get(s);p.unshift(f),p.length>i&&(p.length=i)}if(n===`Network.responseReceived`){let e=t.get(s);if(!e)return;let n=e.find(e=>e.id===c.requestId);if(!n)return;let r={};if(c.response?.headers)for(let[e,t]of Object.entries(c.response.headers))r[e]=String(t);n.status=c.response?.status||null,n.responseHeaders=r}if(n===`Network.loadingFinished`){let n=t.get(s);if(!n)return;let r=n.find(e=>e.id===c.requestId);if(!r)return;chrome.debugger.sendCommand(e,`Network.getResponseBody`,{requestId:c.requestId},e=>{if(!chrome.runtime.lastError&&e?.body)if(e.base64Encoded)try{r.responseBody=atob(e.body)}catch{r.responseBody=`[Binary Data]`}else r.responseBody=e.body})}if(n===`Network.loadingFailed`){let e=t.get(s);if(!e)return;let n=e.find(e=>e.id===c.requestId);n&&n.status===null&&(n.status=0)}})}catch{}try{chrome.debugger.onDetach.addListener(e=>{e.tabId&&(n.delete(e.tabId),n.size===0&&u())})}catch{}chrome.tabs.onRemoved.addListener(e=>{t.delete(e),n.has(e)&&(n.delete(e),n.size===0&&u())}),chrome.windows.onRemoved.addListener(t=>{t===e&&(e=null)});